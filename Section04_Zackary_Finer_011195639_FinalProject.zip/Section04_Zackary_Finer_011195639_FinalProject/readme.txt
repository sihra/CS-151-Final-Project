011195639 (Finer, Zackary)

011935326 (Melesse, Alemnew)

011199630 (Shira, Gurdev)

Instructions:
1. Please find the TaskList.jar file located in the directory you found this readme file in, and run it.
2. Once the application opens, type admin for the username and then admin for the password, and press the login button.
3. Once you enter the task view mode, you can hit Create new project to begin editing a new project.
4. You can add tasks to the columns by pressing the + buttons located at the bottom of each task column in the project view.
5. You can transfer tasks to different columns by dragging them to the title of the column you would like to add them to.
6. When a color for the task selected is chosen, the edit popUp button "okay" must be pressed before the color will appear.
7. You can add columns to a project by entering a title and pressing the add column button at the bottom of the window,
or by pressing the edit button and clicking the add column button.
8. You can add projects to an existing task board by clicking the create new project button.
9. You can load and save projects by pressing the load and save buttons.

Additional Features:
Ability to add multiple columns to a project
Ability to Drag and Drop tasks from one column to another
Ability to change the color of tasks