import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import javax.sound.midi.ControllerEventListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.tools.JavaFileManager;

public class MainScreen extends JFrame implements ViewInterface, WindowListener {
	private ProjectView projView;
	private TaskBoardEditPanel editP;
	private SpringLayout layout;
	private TaskBoardController controller;
	private HomePageView hp;
	public ProjectView getProjectView() {
		return projView;
	}

	public void setProjectView(ProjectModel p) {
		projView = new ProjectView(p);
	}

	public TaskBoardController getTBController() {
		return controller;
	}

	// private TaskBoardView tBView;
	private TaskBoardModel data;

	public void update() {
		projView.update();
		revalidate();
		repaint();
	}

	public MainScreen(TaskBoardModel _data) {
		data = _data;
		controller = new TaskBoardController(data);
		data.attach(this);
		setLayout(new BorderLayout());
		projView = new ProjectView(data.getSelectedModel());
		editP = new TaskBoardEditPanel(_data, this);
		add(editP, BorderLayout.NORTH);
		add(projView, BorderLayout.SOUTH);
		// pack();
	}

	public void updateSelectedView() {
		MainScreen ext = this;
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				if (data.getSelectedModel()!=null && data.getProjectList().size()> 0)
				{
					if (hp!=null)
					{
						remove(hp);
						layout.removeLayoutComponent(hp);
						hp=null;
					}
				remove(projView);
				layout.removeLayoutComponent(projView);
				
				projView = new ProjectView(data.getSelectedModel());
				layout.putConstraint(SpringLayout.NORTH, projView, 0, SpringLayout.SOUTH, editP);
				layout.putConstraint(SpringLayout.SOUTH, projView, 0, SpringLayout.SOUTH, ext.getContentPane());

				layout.putConstraint(SpringLayout.WEST, projView, 0, SpringLayout.WEST, ext.getContentPane());
				layout.putConstraint(SpringLayout.EAST, projView, 0, SpringLayout.EAST, ext.getContentPane());

				add(projView);
				revalidate();
				}
				else
				{
					remove(projView);
					layout.removeLayoutComponent(projView);
					hp = new HomePageView();
					hp.setVariable(ext);
					layout.putConstraint(SpringLayout.NORTH, hp, 0, SpringLayout.SOUTH, editP);
					layout.putConstraint(SpringLayout.SOUTH, hp, 0, SpringLayout.SOUTH, ext.getContentPane());
					layout.putConstraint(SpringLayout.WEST, hp, 0, SpringLayout.WEST, ext.getContentPane());
					layout.putConstraint(SpringLayout.EAST, hp, 0, SpringLayout.EAST, ext.getContentPane());
					add(hp);
					revalidate();
				}
			}
		});
	}

	public void setLoggedIn(boolean b) {
		MainScreen ext = this;
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {

				ext.getContentPane().removeAll();
				if (b) {
					if (data == null) {
						data = new TaskBoardModel();
					}
					setLayout(new BorderLayout());
					projView = new ProjectView();
					editP = new TaskBoardEditPanel(data, ext);
					data.attach(editP);
					controller = data.getController();
					layout = new SpringLayout();
					setLayout(layout);
					layout.putConstraint(SpringLayout.NORTH, editP, 0, SpringLayout.NORTH, ext.getContentPane());
					layout.putConstraint(SpringLayout.WEST, editP, 0, SpringLayout.WEST, ext.getContentPane());
					layout.putConstraint(SpringLayout.EAST, editP, 0, SpringLayout.EAST, ext.getContentPane());
					
					layout.preferredLayoutSize(ext);

					layout.putConstraint(SpringLayout.NORTH, projView, 50, SpringLayout.NORTH, ext.getContentPane());
					layout.putConstraint(SpringLayout.SOUTH, projView, 0, SpringLayout.SOUTH, ext.getContentPane());

					getContentPane().add(editP);
					getContentPane().add(projView);
					pack();
					setSize(500, 500);
					setMinimumSize(new Dimension(600, 700));
					setExtendedState(JFrame.MAXIMIZED_BOTH);
				} else {
					LoginView lc = new LoginView();
					lc.setParent(ext);
					setLayout(new BorderLayout());
					getContentPane().add(lc, BorderLayout.CENTER);
					revalidate();
					repaint();
					// pack();
				}
			}
		});
	}
	public MainScreen() {
		addWindowListener(this);
		setSize(500, 500);
		setLoggedIn(false);
	}

	public void setData(TaskBoardModel _data) {
		data = _data;
		data.attach(this);
		editP.setData(data);
		data.notifyViews();
		updateSelectedView();
	}

	public static void main(String[] args) {
		MainScreen view = new MainScreen();
		view.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		view.setVisible(true);
	}

	@Override
	public void windowOpened(WindowEvent e) {}

	@Override
	public void windowIconified(WindowEvent e) {}

	@Override
	public void windowDeiconified(WindowEvent e) {}

	@Override
	public void windowDeactivated(WindowEvent e) {}

	@Override
	public void windowClosing(WindowEvent e) {
		if (data != null && data.getController().needSave()) {
			int result = JOptionPane.showConfirmDialog(this,
					"You are about to close the application, any unsaved work will be lost.\n Are you sure you would like to continue?",
					null, JOptionPane.OK_CANCEL_OPTION);
			switch (result) {
			case JOptionPane.CANCEL_OPTION:
				break;
			default:
				dispose();
				System.exit(0);
				break;
			}
		} else {
			dispose();
			System.exit(0);
		}
	}

	@Override
	public void windowClosed(WindowEvent e) {}

	@Override
	public void windowActivated(WindowEvent e) {}
}

class TaskBoardEditPanel extends JPanel implements ViewInterface {
	private TaskBoardModel data;
	private TaskBoardController controller;

	public void setData(TaskBoardModel _data) {
		data = _data;
		data.attach(this);
	}

	private MainScreen parentScr;
	private JButton createNewB;
	private JButton editB;
	private JButton saveB;
	private JButton loadB;
	private JButton delete;
	private JComboBox<ProjectModel> sectionCB;

	public TaskBoardEditPanel(TaskBoardModel _data, MainScreen _parent) {
		data = _data;
		controller = data.getController();
		parentScr = _parent;
		data.attach(this);
		for (ProjectModel c : data) {
			c.attach(this);
		}
		editB = new JButton("edit");
		editB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (data.getSelectedModel() != null) {
					ProjectEditView d = new ProjectEditView(data.getSelectedModel());
					d.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					d.setVisible(true);
				}
			}
		});
		createNewB = new JButton("Create New Project");
		createNewB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ProjectEditView d = new ProjectEditView(data.getController());
				d.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				d.setVisible(true);

			}
		});
		delete = new JButton("Delete Project");
		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (controller.getProjectList().size() > 0)
				{
					int dialogResult = JOptionPane.showConfirmDialog(null,
							"In deleting this Project all of your columns and tasks will be erased from the system. Are you sure you want to continue",
							"Project Deletion", JOptionPane.YES_NO_OPTION);
					if (dialogResult == JOptionPane.YES_OPTION) {
						controller.deleteProject(parentScr.getProjectView().getProjectModel());
						parentScr.updateSelectedView();
					}
				}

			}

		});
		saveB = new JButton("save");
		saveB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				int val = fc.showSaveDialog(parentScr);

				if (val == JFileChooser.APPROVE_OPTION) {
					File selected = fc.getSelectedFile();
					data.getController().saveProjectsToFile(selected, data);
				}
			}
		});
		loadB = new JButton("load");
		TaskBoardEditPanel ext = this;
		loadB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				int val = fc.showOpenDialog(parentScr);

				if (val == JFileChooser.APPROVE_OPTION) {
					File selected = fc.getSelectedFile();
					try {
						TaskBoardModel data = TaskFileManager.readFromFile(selected);
						parentScr.setData(data);
						ext.data = data;
						ext.controller = ext.data.getController();
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		sectionCB = new JComboBox<>();
		sectionCB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {

					@Override
					public void run() {
						data.setSelectedIndex(sectionCB.getSelectedIndex());
						if (sectionCB.getSelectedIndex() >= 0) {
							parentScr.updateSelectedView();
						}
					}
				});

			}
		});
		for (ProjectModel c : data) {
			sectionCB.addItem(c);
		}
		if (sectionCB.getItemCount() > 0) {
			sectionCB.setSelectedIndex(0);
		}
		setLayout(new FlowLayout());
		add(sectionCB);
		add(saveB);
		add(loadB);
		add(editB);
		add(delete);
		add(createNewB);

	}

	@Override
	public void update() {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				sectionCB.removeAllItems();
				System.out.println();
				for (ProjectModel c : data) {
					sectionCB.addItem(c);
				}
				revalidate();

			}
		});

	}
}