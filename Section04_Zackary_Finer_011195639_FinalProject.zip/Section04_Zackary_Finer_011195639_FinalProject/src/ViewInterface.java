
public interface ViewInterface {
	public void update();
}
